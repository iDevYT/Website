function Support() {
    alert('Thanks-')
    alert('For supporting Me!')
    console.log('Button_01 Preesed')
}

function Help() {
    alert('Help. You need to Search ')
}

function Sign_in() {
    alert('Sign in...')
}
